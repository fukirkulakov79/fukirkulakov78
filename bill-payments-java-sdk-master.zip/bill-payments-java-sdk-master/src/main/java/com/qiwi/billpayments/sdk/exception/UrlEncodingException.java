package com.qiwi.billpayments.sdk.exception;

public class UrlEncodingException extends RuntimeException {
    public UrlEncodingException(Throwable cause) {
        super(cause);
    }
}
