package com.qiwi.billpayments.sdk.exception;

public class SerializationException extends RuntimeException {
    public SerializationException(Throwable cause) {
        super(cause);
    }
}
