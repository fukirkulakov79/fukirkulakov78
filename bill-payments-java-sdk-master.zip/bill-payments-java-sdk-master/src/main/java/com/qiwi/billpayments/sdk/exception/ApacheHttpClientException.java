package com.qiwi.billpayments.sdk.exception;

public class ApacheHttpClientException extends RuntimeException {
    public ApacheHttpClientException(Throwable cause) {
        super(cause);
    }
}
