package com.qiwi.billpayments.sdk.exception;

public class EncryptionException extends RuntimeException {
    public EncryptionException(Throwable cause) {
        super(cause);
    }
}
