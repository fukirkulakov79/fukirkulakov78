package com.qiwi.billpayments.sdk;

public class PomInfo {
    public static final String VERSION = "${project.version}";
}
